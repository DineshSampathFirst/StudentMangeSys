const Student = require('../models/Student');
const Course = require('../models/Course');

const createStudent = async (name, email, age) => {
  const student = new Student({ name, email, age });
  await student.save();
  console.log('Student Created:', student);
};

const createCourse = async (courseName, instructor, credits) => {
  const course = new Course({ courseName, instructor, credits });
  await course.save();
  console.log('Course Created:', course);
};

const fetchAllStudents = async () => {
  const students = await Student.find();
  console.log('All Students:', students);
};

const fetchStudentsWithCourses = async () => {
  const students = await Student.aggregate([
    {
      $lookup: {
        from: 'courses',
        localField: 'enrolledCourses',
        foreignField: '_id',
        as: 'courses'
      }
    }
  ]);
  console.log('Students with Courses:', JSON.stringify(students, null, 2));
};

const updateStudent = async (studentId, updateData) => {
  const student = await Student.findByIdAndUpdate(studentId, updateData, { new: true });
  console.log('Updated Student:', student);
};

const deleteStudent = async (studentId) => {
  await Student.findByIdAndDelete(studentId);
  console.log('Student Deleted');
};

const deleteCourse = async (courseId) => {
  await Course.findByIdAndDelete(courseId);
  console.log('Course Deleted');
};

module.exports = {
  createStudent,
  createCourse,
  fetchAllStudents,
  fetchStudentsWithCourses,
  updateStudent,
  deleteStudent,
  deleteCourse
};
