const connectDB = require('./config/db');
const {
  createStudent,
  createCourse,
  fetchAllStudents,
  fetchStudentsWithCourses,
  updateStudent,
  deleteStudent,
  deleteCourse
} = require('./operations/crud');

const mongoose = require('mongoose');

const run = async () => {
  await connectDB();

  // === Example Usage ===
  // Create courses
  // const course1 = await createCourse('Mathematics', 'Dr. Smith', 3);
  // const course2 = await createCourse('Physics', 'Dr. Doe', 4);

  // Create a student
  // await createStudent('Alice', 'alice@example.com', 20);

  // Fetch students
  // await fetchAllStudents();

  // Fetch students with their enrolled course details
  // await fetchStudentsWithCourses();

  // Update a student
  // await updateStudent('studentObjectIdHere', { name: 'Alice Johnson' });

  // Delete a student
  // await deleteStudent('studentObjectIdHere');

  // Delete a course
  // await deleteCourse('courseObjectIdHere');

  mongoose.connection.close();
};

run();
