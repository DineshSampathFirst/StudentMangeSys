# Student Management System (MongoDB + Node.js)

## Requirements
- Node.js
- MongoDB (Local or Atlas)

## Setup
1. Install dependencies:
   ```bash
   npm install
   ```

2. Configure MongoDB in `config/db.js` (defaults to local).

3. Run:
   ```bash
   npm start
   ```

4. Edit `index.js` to perform different CRUD operations.

---
Collections:
- students
- courses

Indexing:
- Unique index on student email
- Text index on courseName

Relationships:
- Students can enroll in multiple courses (one-to-many).
