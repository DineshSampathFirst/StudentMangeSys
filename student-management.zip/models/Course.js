const mongoose = require('mongoose');

const CourseSchema = new mongoose.Schema({
  courseName: { type: String, required: true },
  instructor: { type: String },
  credits: { type: Number }
});

CourseSchema.index({ courseName: 'text' });

module.exports = mongoose.model('Course', CourseSchema);
